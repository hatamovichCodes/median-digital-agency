import { useEffect } from "react";

import {
	BrowserRouter as Router,
	Routes,
	Route,
	useLocation,
} from "react-router-dom";
import Home from "./pages/Home";
import SMM from "./pages/SMM";

const ScrollRestoration = () => {
	const { pathname } = useLocation();

	useEffect(() => {
		window.scrollTo(0, 0);
	}, [pathname]);

	return null;
};

const App = () => (
	<Router basename="/">
		<ScrollRestoration />
		<Routes>
			<Route exact="/" path="/" element={<Home />} />
			<Route path="/portfolio/SMM/:id" element={<SMM />} />
			<Route path="*" element={<h1>Page Not Found - 404</h1>} />\
		</Routes>
	</Router>
);

export default App;
