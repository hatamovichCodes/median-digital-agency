import BackgroundVideo from "../../assets/videos/001.mp4";
import { Link } from "react-scroll";

const Header = () => (
	<header className="header">
		<video
			className="header__video"
			autoPlay={true}
			muted={true}
			loop={true}
			playsInline={true}
		>
			<source src={BackgroundVideo} type="video/mp4" />
		</video>

		<div className="container">
			<div className="header__content">
				{/*Content Start*/}
				<h1 className="header__title">Median</h1>
				<span className="header__sub">
					Агентство позволяющее бизнесам расти в интернете
				</span>

				<p className="header__text">
					Направим бизнес на правильный вектор в онлайн формате, что
					позволит увеличить доход
				</p>

				<Link
					className="header__link"
					to="portfolioList"
					spy={true}
					smooth={true}
					offset={-40}
				>
					Портфолио
				</Link>
				{/*Content end*/}
			</div>
		</div>
	</header>
);

export default Header;
