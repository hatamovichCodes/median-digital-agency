import ServicesItem from "../ServicesItem";
import developmentIcon from "../../assets/images/development.png";
import designIcon from "../../assets/images/design.png";
import smmIcon from "../../assets/images/smm.png";

const ServicesList = () => (
	<div className="servicesList">
		<div className="container">
			<div className="servicesList__content">
				{/*Content Start*/}
				<ServicesItem
					title="Разработка сайтов"
					text="Создание статических и динамических сайтов исходя из предпочтений клиентов"
					ico={developmentIcon}
					icoAlt="Иконка веб-разработки"
				/>

				<ServicesItem
					title="SMM"
					text="Ведение и продвижение социальных сетей, таргетированная реклама"
					ico={smmIcon}
					icoAlt="Иконка SMM"
				/>

				<ServicesItem
					title="UI / UX Дизайн"
					text="Разработка уникального дизайна для веб-сайтов и мобильных приложений"
					ico={designIcon}
					icoAlt="Иконка дизайна"
				/>
				{/*Content End*/}
			</div>
		</div>
	</div>
);

export default ServicesList;
