import Instagram from "../../assets/svg/Instagram";
import Telegram from "../../assets/svg/Telegram";
import Facebook from "../../assets/svg/Facebook";

const SocialNetwork = () => {
	return (
		<div className="socialNetwork">
			<h1 className="socialNetwork__title">Мы в социальных сетях</h1>

			<p className="socialNetwork__text">
				Подпишитесь на нас в социальных сетях, мы там делимся пользой
				для развития вашего бизнеса
			</p>

			<div className="socialNetwork__links">
				<a
					className="socialNetwork__link"
					href="https://www.instagram.com/median.uz/"
					rel="noreferrer"
					target="_blank"
				>
					<Instagram />
				</a>
				<a
					className="socialNetwork__link"
					href="https://t.me/median_uz"
					rel="noreferrer"
					target="_blank"
				>
					<Telegram />
				</a>
				<a
					className="socialNetwork__link"
					href="https://www.facebook.com/Median-111372067991012"
					rel="noreferrer"
					target="_blank"
				>
					<Facebook />
				</a>
			</div>
		</div>
	);
};

export default SocialNetwork;
