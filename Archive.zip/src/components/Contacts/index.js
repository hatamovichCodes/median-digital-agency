// Icons
import EmailIcon from "../../assets/images/email.png";
import LocationIcon from "../../assets/images/location.png";
import PhoneIcon from "../../assets/images/phone.png";

// Components
import SocialNetwork from "../SocialNetwork";
import CustomForm from "../CustomForm";

const Contacts = () => {
	return (
		<div className="contacts">
			<div className="container">
				<div className="contacts__content">
					<div className="contacts__left">
						<h1 className="contacts__title">Наши Контакты</h1>

						<p className="contacts__text">
							Вы легко и просто можете связаться с нами, нажмите
							на нижеуказанный номер телефона. Если же вы любите
							формальность, мы ждём ваше письменное обращение на
							наш почтовый адрес.
						</p>

						<div className="contacts__items">
							<a
								className="contacts__item"
								href="mailTo:medianInbox@gmail.com"
							>
								<img
									className="contacts__icon"
									src={EmailIcon}
									alt="Icon of e-mail"
								/>
								<span className="contacts__text">
									MedianInbox@gmail.com
								</span>
							</a>

							<a
								className="contacts__item"
								href="https://www.google.com/maps/@41.2940326,69.2239968,16z"
								rel="noreferrer"
								target="_blank"
							>
								<img
									className="contacts__icon"
									src={LocationIcon}
									alt="Icon of location"
								/>
								<span className="contacts__text">
									Проспект Бунёдкор, станция метро имени
									Новза. Ориентир - Агробанк чиланзарский фл.
								</span>
							</a>

							<a
								className="contacts__item"
								href="tel:+998999004334"
							>
								<img
									className="contacts__icon"
									src={PhoneIcon}
									alt="Icon of mobile phone"
								/>
								<span className="contacts__text">
									+998 (99) 707 49 22
								</span>
							</a>
						</div>

						<SocialNetwork />
					</div>

					<div className="contacts__right">
						<CustomForm />
					</div>
				</div>
			</div>
		</div>
	);
};

export default Contacts;
