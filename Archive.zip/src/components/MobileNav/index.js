import { motion, AnimatePresence } from "framer-motion";

const MobileNav = ({ children, isActive, ...props }) => {
	return (
		<AnimatePresence>
			{isActive && <motion.nav {...props}>{children}</motion.nav>}
		</AnimatePresence>
	);
};

export default MobileNav;
