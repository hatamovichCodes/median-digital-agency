import Logo from "../../assets/images/logo.png";

const About = () => (
	<div className="about">
		<div className="container">
			<div className="about__content">
				{/*Content Start*/}
				<div className="about__left">
					<img className="about__img" src={Logo} alt="" />
				</div>

				<div className="about__right">
					<div className="about__head">
						<h2 className="about__title">О Нас</h2>
						<h3 className="about__sub">Мы заботимся о клиенте</h3>
					</div>

					<div className="about__body">
						<p className="about__text">
							Median - это команда сертифицированных и опытных
							специалистов. Наша основная цель создать лучшие
							условия для совместной работы и довести каждый
							проект до желаемого результата. Работая с нами вы
							получаете прозрачность в процессе, ответственность,
							креативный подход и практичность.
						</p>

						<p className="about__text">
							С вашим проектом будут работать: веб разработчик,
							ui/ux дизайнер, смм специалист, таргетолог, дизайнер
							и мобильный видеограф.
						</p>
					</div>
				</div>
				{/*Content End*/}
			</div>
		</div>
	</div>
);

export default About;
