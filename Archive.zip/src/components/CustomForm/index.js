import { Formik, Form } from "formik";
import * as Yup from "yup";
import { send } from "emailjs-com";
import CustomInput from "../CustomInput";

const CustomForm = () => {
	const initialValues = { name: "", email: "", phone: "" };

	const validationSchema = Yup.object().shape({
		name: Yup.string("Пожалуйста, заполните поле корректно")
			.max(20, "Это поле не должно содержать более 20 букв!")
			.required("Это поле не может быть пустым"),
		email: Yup.string().email(
			"Пожалуйста, введите корректный почтовый адрес"
		),
		phone: Yup.string()
			.matches(
				/(?:\+\(*[9]{2}[8]\)*\ *[0-9]{2}\ *[0-9]{3}(\-| )*[0-9]{2}(\-| )*[0-9]{2})/,
				"Неверный номер телефона"
			)
			.required("Это поле не может быть пустым"),
	});

	const handleSubmit = (values, { setSubmitting, resetForm }) => {
		setTimeout(() => {
			handleSendEmail(values);
			resetForm();
			setSubmitting(false);
		}, 1000);
	};

	const handleSendEmail = (values) => {
		send(
			"service_52kund8",
			"template_5jiv24x",
			values,
			"user_8Hg3zJhzuJX14r1M9WQj3"
		).then(
			function (response) {
				console.log("SUCCESS!", response.status, response.text);
				alert("Спасибо за обращение к нам, мы скоро свяжемся с вами.");
			},
			function (error) {
				console.log("FAILED...", error);
				alert("Не удалось отправить запрос, попробуйте заново.");
			}
		);
	};

	return (
		<Formik
			initialValues={initialValues}
			validationSchema={validationSchema}
			onSubmit={handleSubmit}
		>
			{(formik) => {
				return (
					<Form className="customForm">
						<h1 className="customForm__title">
							Обсудим ваш проект
						</h1>

						<p className="customForm__text">
							Оставьте свои данные. В краткий срок наши
							специалисты свяжутся с вами и проконсультируют на
							интересующие вас темы.
						</p>

						<CustomInput
							name="name"
							type="text"
							placeholder="Ваше Имя*"
						/>
						<CustomInput
							name="email"
							type="text"
							placeholder="Ваш почтовый адрес"
						/>
						<CustomInput
							name="phone"
							placeholder="Ваш номер телефона*"
							type="tel"
						/>

						<button className="customForm__submit" type="submit">
							Отправить
						</button>
					</Form>
				);
			}}
		</Formik>
	);
};

export default CustomForm;
