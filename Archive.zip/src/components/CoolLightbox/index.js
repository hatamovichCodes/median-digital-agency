import Lightbox from "react-spring-lightbox";
import { GrFormPrevious, GrFormNext } from "react-icons/gr";

const CoolLightbox = ({
	images,
	isOpen,
	currentIndex,
	setCurrentIndex,
	onClose,
}) => {
	const gotoPrevious = () =>
		currentIndex > 0 && setCurrentIndex(currentIndex - 1);

	const gotoNext = () =>
		currentIndex + 1 < images.length && setCurrentIndex(currentIndex + 1);

	return (
		<Lightbox
			className="lightbox"
			isOpen={isOpen}
			onPrev={gotoPrevious}
			onNext={gotoNext}
			images={images}
			currentIndex={currentIndex}
			loop={true}
			onClose={onClose}
			renderPrevButton={() => (
				<div onClick={gotoPrevious} className="lightbox-prev">
					<GrFormPrevious />
				</div>
			)}
			renderNextButton={() => (
				<div onClick={gotoNext} className="lightbox-next">
					<GrFormNext />
				</div>
			)}
			/* Add your own UI */
			// renderHeader={() => (<CustomHeader />)}
			// renderFooter={() => (<CustomFooter />)}
			// renderPrevButton={() => (<CustomLeftArrowButton />)}
			// renderNextButton={() => (<CustomRightArrowButton />)}
			// renderImageOverlay={() => (<ImageOverlayComponent >)}

			/* Add styling */
			// className="cool-class"
			// style={{ background: "grey" }}

			/* Handle closing */

			/* Use single or double click to zoom */
			// singleClickToZoom

			/* react-spring config for open/close animation */
			// pageTransitionConfig={{
			//   from: { transform: "scale(0.75)", opacity: 0 },
			//   enter: { transform: "scale(1)", opacity: 1 },
			//   leave: { transform: "scale(0.75)", opacity: 0 },
			//   config: { mass: 1, tension: 320, friction: 32 }
			// }}
		/>
	);
};

export default CoolLightbox;
