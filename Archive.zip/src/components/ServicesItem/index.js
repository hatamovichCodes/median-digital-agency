const ServicesItem = ({ title, text, ico, icoAlt }) => (
	<div className="servicesItem">
		<div className="servicesItem__head">
			<img className="servicesItem__ico" src={ico} alt={icoAlt && ""} />
			<h2 className="servicesItem__title">{title}</h2>
		</div>

		<div className="servicesItem__body">
			<p className="servicesItem__text">{text}</p>
		</div>
	</div>
);

export default ServicesItem;
