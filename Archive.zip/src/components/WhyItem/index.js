const WhyItem = ({ title, text, ico, icoAlt }) => (
	<div className="whyItem">
		{/*Content Start*/}
		<div className="whyItem__left">
			<img className="whyItem__ico" src={ico} alt={icoAlt && ""} />
		</div>

		<div className="whyItem__right">
			<h4 className="whyItem__title">{title}</h4>
			<p className="whyItem__text">{text}</p>
		</div>
		{/*Content End*/}
	</div>
);

export default WhyItem;
