const PricingItem = ({ title, cost, ico, icoAlt, children }) => (
	<div className="pricingItem">
		<div className="pricingItem__head">
			<img className="pricingItem__ico" src={ico} alt={icoAlt} />
			<h2 className="pricingItem__title">{title}</h2>
			<span className="pricingItem__cost">{cost}</span>
		</div>

		<div className="pricingItem__body">{children}</div>

		<div className="pricingItem__foot">
			<a
				className="pricingItem__link"
				href="https://t.me/median_uz"
				rel="noreferrer"
				target="_blank"
			>
				Подробнее
			</a>
		</div>
	</div>
);

export default PricingItem;
