import { useState, useEffect, useRef } from "react";
import { data, categories } from "../../assets/database/portfolio/data";
import { Link } from "react-scroll";

import PortfolioItem from "../PortfolioItem";

const PortfolioList = () => {
	const [items, setItems] = useState([]);
	const [limit, setLimit] = useState(3);
	const [btnIndex, setBtnIndex] = useState(false);
	const itemsRef = useRef(0);
	let conditionalLink = limit === items.length ? "portfolioList" : "";

	const handleDataChange = (event, index) => {
		if (index === false) {
			setBtnIndex(false);
		} else {
			setBtnIndex(index);
		}

		const { value: keyword } = event.target;

		const filteredData = data.filter((item) =>
			item.category.includes(keyword)
		);

		keyword === "all" ? setItems(data) : setItems(filteredData);

		const classValue = "portfolioList__items--animated";

		if (itemsRef.current) {
			itemsRef.current.classList.add(classValue);

			setTimeout(() => {
				itemsRef.current.classList.remove(classValue);
			}, 300);
		}
	};

	const handleLimitedItems = () => items.slice(0, limit);

	useEffect(() => {
		setItems(data);

		return () => false;
	}, [setItems]);

	return (
		<div className="portfolioList">
			<div className="container">
				<div className="portfolioList__content">
					<div className="portfolioList__btns">
						<button
							onClick={(event) => handleDataChange(event, false)}
							value="all"
							className="portfolioList__btn"
						>
							Все работы
							<span
								className={
									false === btnIndex
										? "portfolioList__btn-indicator portfolioList__btn-indicator--active"
										: "portfolioList__btn-indicator"
								}
							/>
						</button>
						{categories.map((category, index) => (
							<button
								onClick={(event) =>
									handleDataChange(event, index)
								}
								value={category.family}
								key={index}
								className="portfolioList__btn"
							>
								{category.name}

								<span
									className={
										index === btnIndex
											? "portfolioList__btn-indicator portfolioList__btn-indicator--active"
											: "portfolioList__btn-indicator"
									}
								/>
							</button>
						))}
					</div>

					<div ref={itemsRef} className="portfolioList__items">
						{items.length ? (
							handleLimitedItems().map((item) => (
								<PortfolioItem
									key={item.id}
									id={item.id}
									title={item.title}
									text={item.text.substring(0, 125) + "..."}
									family={item.category}
									imgURL={item.imgURL}
									pageURL={item.pageURL}
								/>
							))
						) : (
							<div className="portfolioList__items--404">
								Данные не найдены
							</div>
						)}
					</div>

					{items.length > 0 ? (
						<div className="portfolioList__loaders">
							<Link
								to={conditionalLink}
								smooth={true}
								spy={true}
								offset={-40}
								onClick={() => {
									if (limit < items.length) {
										setLimit(
											(prev) => (prev = items.length)
										);
									} else {
										setLimit((prev) => (prev = 3));
									}
								}}
								className="portfolioList__loadMore"
							>
								{limit === items.length
									? "Показать меньше"
									: "Показать больше"}
							</Link>
						</div>
					) : null}
				</div>
			</div>
		</div>
	);
};

export default PortfolioList;
