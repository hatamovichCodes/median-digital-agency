import { Link } from "react-router-dom";

const PortfolioItem = ({ id, imgURL, title, text, family, pageURL }) => {
	return family.toLowerCase() === "smm".toLowerCase() ? (
		<Link
			to={`/portfolio/${family.toLowerCase() + "/" + id}`}
			className="portfolioItem"
		>
			<img className="portfolioItem__img" src={imgURL} alt="" />

			<div className="portfolioItem__body">
				<h3 className="portfolioItem__title">{title}</h3>
				<p className="portfolioItem__text">{text}</p>

				<span className="portfolioItem__link">Подробнее</span>
			</div>
		</Link>
	) : (
		<a href={pageURL} className="portfolioItem">
			<img className="portfolioItem__img" src={imgURL} alt="" />

			<div className="portfolioItem__body">
				<h3 className="portfolioItem__title">{title}</h3>
				<p className="portfolioItem__text">{text}</p>

				<span className="portfolioItem__link">Перейти на сайт</span>
			</div>
		</a>
	);
};

export default PortfolioItem;
