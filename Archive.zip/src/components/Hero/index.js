import { Link } from "react-router-dom";
import { RiArrowLeftLine } from "react-icons/ri";

const Hero = ({ title, text, imgURL, className, children }) => (
	<div className={className ? className : "hero"}>
		<div className="container">
			<div className="hero__content">
				<Link to="/" className="hero__home">
					Главная страница
				</Link>

				<Link to="/" className="hero__back">
					<RiArrowLeftLine />
				</Link>

				{/*Content Start*/}
				<div className="hero__left">
					<h1 className="hero__title">{title}</h1>
					<p className="hero__text">{text}</p>

					{children}
				</div>

				<div className="hero__right">
					<img className="hero__img" src={imgURL} alt="" />
				</div>
				{/*Content End*/}
			</div>
		</div>
	</div>
);

export default Hero;
