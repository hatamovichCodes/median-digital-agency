import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";

const Carousel = ({ images, handleLightboxOpen }) => {
	const settings = {
		infinite: true,
		dots: true,
		speed: 500,
		arrows: false,
		slidesToShow: 3,
		slidesToScroll: 3,
		centerMode: false,
		autoplay: true,
		autplaySpeed: 1000,
		responsive: [
			{
				breakpoint: 769,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1,
				},
			},

			{
				breakpoint: 600,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				},
			},
		],
	};

	return (
		<Slider className="carousel" {...settings}>
			{images &&
				images.map((image, index) => (
					<div
						onClick={() => handleLightboxOpen(index)}
						key={index}
						className="carousel__item"
					>
						<img
							className="carousel__img"
							alt={image.alt}
							src={image.src}
						/>
					</div>
				))}
		</Slider>
	);
};

export default Carousel;
