import { useEffect, useRef } from "react";
import lottie from "lottie-web";

import WhyItem from "../WhyItem";

import BackgroundVideo from "../../assets/videos/002.mp4";

import NumberIcon from "../../assets/images/number.png";
import globalIcon from "../../assets/images/globe.png";
import portfolioIcon from "../../assets/images/portfolio.png";
import projectIcon from "../../assets/images/project.png";
import GrowthLottie from "../../assets/animations/growth";

const WhyList = () => {
	const lottieContainer = useRef(null);

	useEffect(() => {
		lottie.loadAnimation({
			container: lottieContainer.current,
			renderer: "svg",
			loop: true,
			autoplay: true,
			animationData: GrowthLottie,
		});

		return () => false;
	}, []);

	return (
		<div className="whyList">
			<video
				className="whyList__video"
				autoPlay={true}
				muted={true}
				loop={true}
			>
				<source src={BackgroundVideo} type="video/mp4" />
			</video>

			<div className="container">
				<div className="whyList__content">
					{/*Content Start */}
					<div className="whyList__left">
						{/*Here Will be the animation*/}
						<div
							className="whyList__lottie"
							ref={lottieContainer}
						></div>
					</div>

					<div className="whyList__right">
						<div className="whyList__head">
							<img
								className="whyList__num"
								src={NumberIcon}
								alt=""
							/>

							<h1 className="whyList__title">
								<span className="whyList__titleSup">
									Причины
								</span>
								Выбрать нас
							</h1>

							<h3 className="whyList__sub">
								Сделайте один раз правильный выбор, что бы
								сэкономить время и нервы в будущем.
							</h3>
						</div>

						<div className="whyList__body">
							<WhyItem
								title="Международный опыт"
								text="Работая с зарубежным рынком, мы получили опыт иного ведение бизнеса, перепробовали многие механики продвижения, и контроль качества."
								ico={globalIcon}
								icoAlt="Иконка глобуса"
							/>

							<WhyItem
								title="Проделанные работы в десяти нишах"
								text="Товарный бизнес, общепит, онлайн платформы, сфера образования и др. Более подробно можете изучить в нашем портфолио."
								ico={portfolioIcon}
								icoAlt="Иконка портфолио"
							/>

							<WhyItem
								title="Мы не копируем - Мы создаем"
								text="Индвидуальный подход к каждому клиенту - никаких шаблонов, гарантированное качество и результат"
								ico={projectIcon}
								icoAlt="Иконка разработки"
							/>
						</div>
					</div>
					{/*Content End */}
				</div>
			</div>
		</div>
	);
};

export default WhyList;
