import { useState, useEffect, useRef } from "react";
import { Link } from "react-scroll";
import Logo from "../../assets/images/Median.png";
import { Cross as Hamburger } from "hamburger-react";

import MobileNav from "../MobileNav";

const Navbar = () => {
	const [isActive, setIsActive] = useState(false);
	const refference = useRef(null);

	useEffect(() => {
		window.addEventListener("scroll", () => {
			refference.current &&
				refference.current.classList.toggle(
					"active",
					window.scrollY > 25
				);
		});

		return () => false;
	}, []);

	const handleToggler = () => setIsActive(false);

	return (
		<nav ref={refference} className="navbar">
			<div className="container">
				<div className="navbar__content">
					<div className="navbar__brand">
						<img className="navbar__logo" src={Logo} alt="" />
					</div>

					<Hamburger toggled={isActive} onToggle={setIsActive} />

					<MobileNav
						className="mobileNav"
						isActive={isActive}
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						exit={{ opacity: 0 }}
						transition={{ duration: 0.5 }}
					>
						<Link
							onClick={handleToggler}
							spy={true}
							smooth={true}
							to="header"
							className="mobileNav__link"
						>
							Главная
						</Link>
						<Link
							onClick={handleToggler}
							spy={true}
							smooth={true}
							offset={-80}
							to="about"
							className="mobileNav__link"
						>
							О Нас
						</Link>
						<Link
							onClick={handleToggler}
							spy={true}
							smooth={true}
							to="whyList"
							offset={-20}
							className="mobileNav__link"
						>
							Почему мы
						</Link>
						<Link
							onClick={handleToggler}
							spy={true}
							smooth={true}
							to="portfolioList"
							offset={-55}
							className="mobileNav__link"
						>
							Портфолио
						</Link>
						<Link
							onClick={handleToggler}
							spy={true}
							smooth={true}
							to="pricingList"
							offset={-35}
							className="mobileNav__link"
						>
							Тарифы
						</Link>
						<Link
							onClick={handleToggler}
							spy={true}
							smooth={true}
							offset={-50}
							to="contacts"
							className="mobileNav__link"
						>
							Контакты
						</Link>
					</MobileNav>

					<div className="navbar__nav">
						<Link
							spy={true}
							smooth={true}
							to="header"
							className="navbar__link"
						>
							Главная
						</Link>
						<Link
							spy={true}
							smooth={true}
							offset={-200}
							to="about"
							className="navbar__link"
						>
							О Нас
						</Link>
						<Link
							spy={true}
							smooth={true}
							to="whyList"
							offset={10}
							className="navbar__link"
						>
							Почему Мы
						</Link>
						<Link
							spy={true}
							smooth={true}
							to="portfolioList"
							offset={-40}
							className="navbar__link"
						>
							Портфолио
						</Link>
						<Link
							spy={true}
							smooth={true}
							to="pricingList"
							offset={0}
							className="navbar__link"
						>
							Тарифы
						</Link>
						<Link
							spy={true}
							smooth={true}
							to="contacts"
							className="navbar__link"
						>
							Контакты
						</Link>
					</div>
				</div>
			</div>
		</nav>
	);
};

export default Navbar;
