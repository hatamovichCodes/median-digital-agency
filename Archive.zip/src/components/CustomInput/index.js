import { useField } from "formik";

const CustomInput = ({ ...props }) => {
	const [field, meta] = useField(props);

	return (
		<div className="customInput">
			<input
				className="customInput__input"
				autoComplete="off"
				{...field}
				{...props}
			/>

			{meta.touched && meta.error ? (
				<p className="customInput__error">{meta.error}</p>
			) : null}
		</div>
	);
};

export default CustomInput;
