import PricingItem from "../PricingItem";
import tickIcon from "../../assets/images/tick.png";
import developmentIcon from "../../assets/images/development.png";
import designIcon from "../../assets/images/design.png";
import smmIcon from "../../assets/images/smm.png";

const PricingList = () => (
	<div className="pricingList">
		<div className="pricingList__banner">
			<div className="container">
				<h2 className="pricingList__bannerTitle">Тарифы</h2>

				<h3 className="pricingList__bannerSub">
					Мы обсудим цены исходя из ваших требований и создадим для
					Вас лучшие условия, учитывая все ваши желания и
					предпочтения. Вы не покупаете у нас услуги, а делаете
					инвестиции в свою долгосрочную прибыль.
				</h3>
			</div>
		</div>

		<div className="container">
			{/*Content Start*/}
			<div className="pricingList__content">
				<PricingItem
					title="Веб-Сайты"
					cost="от 2.500.000 сум"
					ico={developmentIcon}
					icoAlt="иконка"
				>
					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Динамический сайт
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							до 5 страниц
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Уникальный дизайн
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Ручной код
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Бесплатный домен
						</span>
					</div>
				</PricingItem>

				<PricingItem
					title="SMM"
					cost="от 2.800.000 сум"
					ico={smmIcon}
					icoAlt="иконка"
				>
					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Стратегия продвижения
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Контент план
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Персональный дизайн
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Таргетинг и копирайтинг
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Мобильное видео в подарок
						</span>
					</div>
				</PricingItem>

				<PricingItem
					title="UI / UX - Дизайн"
					cost="от 1.000.000 сум"
					ico={designIcon}
					icoAlt="иконка"
				>
					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							UX исследование
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Карта пользователя
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Дизайн до 5 страниц
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Уникальная типография
						</span>
					</div>

					<div className="pricingItem__item">
						<img
							className="pricingItem__itemIco"
							src={tickIcon}
							alt="иконка"
						/>
						<span className="pricingItem__itemText">
							Прототипирование
						</span>
					</div>
				</PricingItem>
			</div>
			{/*Content End*/}
		</div>
	</div>
);

export default PricingList;
