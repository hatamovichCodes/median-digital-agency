export const categories = [
	{
		id: 1,
		name: "Веб-Сайты",
		family: "Development",
	},
	{
		id: 2,
		name: "SMM",
		family: "SMM",
	},
];

export const [Dev, SMM] = categories;
