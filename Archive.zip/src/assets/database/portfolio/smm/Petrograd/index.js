import { SMM } from "../../categories";
// Images
import logo from "./images/logo.png";
import img001 from "./images/001.jpg";
import img002 from "./images/002.jpg";
import img003 from "./images/003.jpg";
import img004 from "./images/004.jpg";

const Petrograd = {
	id: 3,
	title: "ПетроГрадь",
	text: "Агентство ПетроГрадь из Санкт-Петербурга, Россия. Предоставляют услуги: ремонт под ключ и разработка дизайн проекта.",
	category: SMM.family,
	imgURL: img001,
	logoURL: logo,
	task: "Упаковать профиль за короткий срок",
	resultItems: [
		"Выполнен конкурентный анализ",
		"Составлен контент план с рубрикатором",
		"Подборка фирменных цветов и шрифта исходя из логотипа агентства",
		"Сгенерированно 18 публикаций по контент плану и 30 сторисов",
		"Сделан один рекламный баннер с акцией",
		"Заполнили хайлайтс",
	],
	resultText:
		"Работа была сдана точно в срок, как было согласовано по первой договоренности",
	gallery: [
		{ src: img001, alt: "Картинка поста в instagram" },
		{ src: img002, alt: "Картинка поста в instagram" },
		{ src: img003, alt: "Картинка поста в instagram" },
		{ src: img004, alt: "Картинка поста в instagram" },
	],
};

export default Petrograd;
