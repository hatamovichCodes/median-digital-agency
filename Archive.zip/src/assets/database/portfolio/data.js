import { categories } from "./categories";

// SMM Portfolio items
import PandaDonar from "./smm/PandaDonar";
import Lion from "./smm/Lion";
import GasanovCosmetics from "./smm/GasanovCosmetics";
import Petrograd from "./smm/Petrograd";
import DobrieDveri from "./smm/DobrieDveri";
import SamsungKredit from "./smm/SamsungKredit";

const data = [
	PandaDonar,
	Lion,
	SamsungKredit,
	GasanovCosmetics,
	Petrograd,
	DobrieDveri,
];

const getDataById = (id) => data.find((item) => Number(item.id) === Number(id));

export { data, categories, getDataById };
