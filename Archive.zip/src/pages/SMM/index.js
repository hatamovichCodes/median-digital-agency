import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { getDataById } from "../../assets/database/portfolio/data";
import Contacts from "../../components/Contacts";
import Hero from "../../components/Hero";
import Carousel from "../../components/Carousel";
import CoolLightbox from "../../components/CoolLightbox";

const SMM = () => {
	const { id } = useParams();
	const [data, setData] = useState({});
	const [result, setResult] = useState([]);
	const [resultItems, setResultItems] = useState([]);
	const [gallery, setGallery] = useState([]);
	const [isLightboxOpen, setIsLightboxOpen] = useState(false);
	const [currentIndex, setCurrentIndex] = useState(0);

	const handleLightboxOpen = (index) => {
		setIsLightboxOpen(true);
		setCurrentIndex(index);
	};
	const handleLightboxClose = () => {
		setIsLightboxOpen(false);
		setCurrentIndex(0);
	};

	useEffect(() => {
		const currentData = getDataById(id);
		const currentGallery = currentData.gallery && currentData.gallery;
		const currentResult = currentData.result && currentData.result;
		const currentResultItems =
			currentData.resultItems && currentData.resultItems;

		setData(currentData && currentData);
		setGallery(currentGallery);
		setResult(currentResult);
		setResultItems(currentResultItems);

		return () => false;
	}, [data, id]);

	return data ? (
		<>
			<Hero title={data.title} text={data.text} imgURL={data.logoURL} />

			<div className="smm">
				<div className="container">
					<div className="smm__content">
						{/*Content Start*/}
						{result && (
							<div className="smmStats">
								{result.slice(0, 3).map((item, index) => (
									<div key={index} className="smmStats__item">
										<span className="smmStats__number">
											{item.value}
										</span>
										<p className="smmStats__text">
											{item.name}
										</p>
									</div>
								))}
							</div>
						)}

						<div className="smmClient">
							<span className="smmClient__title">
								Поставленная задача
							</span>
							<img
								className="smmClient__img"
								src="https://cdn0.iconfinder.com/data/icons/app-collection/128/Task_assigned_done-512.png"
								alt=""
							/>
							<p className="smmClient__text">{data.task}</p>
						</div>

						<div className="smmResult">
							<div className="smmResult__left">
								<h3 className="smmResult__title">Результат</h3>

								{result && (
									<ul className="smmResult__list">
										{resultItems.map((item, index) => (
											<li
												className="smmResult__listItem"
												key={index}
											>
												{item}
											</li>
										))}
									</ul>
								)}
							</div>

							<div className="smmResult__right">
								{result && result.length
									? result.map((item, index) => (
											<div
												key={index}
												className="smmResult__item"
											>
												<p className="smmResult__number">
													{item.value}
												</p>
												<p className="smmResult__info">
													{item.name}
												</p>
											</div>
									  ))
									: null}

								<p className="smmResult__text">
									{data.resultText}
								</p>
							</div>
						</div>

						{gallery && (
							<div className="smmGallery">
								<span className="smmGallery__title">
									Галерея наших работ
								</span>

								<p className="smmGallery__text">
									Нажав на картинку вы можете увидеть дизайн
									постов в полноэкранном режиме, чтобы увидеть
									больше постов пролистайте слайдер.
								</p>

								<Carousel
									images={gallery}
									handleLightboxOpen={handleLightboxOpen}
								/>

								<CoolLightbox
									images={gallery}
									currentIndex={currentIndex}
									isOpen={isLightboxOpen}
									onClose={handleLightboxClose}
									setCurrentIndex={setCurrentIndex}
								/>
							</div>
						)}
						{/*Content End*/}
					</div>
				</div>
			</div>

			<Contacts />
		</>
	) : (
		<div>Data not found</div>
	);
};

export default SMM;
