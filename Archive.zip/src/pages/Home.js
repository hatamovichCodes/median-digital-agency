import Navbar from "../components/Navbar";
import Header from "../components/Header";
import ServicesList from "../components/ServicesList";
import About from "../components/About";
import WhyList from "../components/WhyList";
import PortfolioList from "../components/PortfolioList";
import PricingList from "../components/PricingList";
import Contacts from "../components/Contacts";

const Home = () => (
	<div className="HomePage">
		<Navbar />
		<Header />
		<ServicesList />
		<About />
		<WhyList />
		<PortfolioList />
		<PricingList />
		<Contacts />
	</div>
);

export default Home;
